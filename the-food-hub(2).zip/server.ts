import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("foodhub.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    name TEXT,
    verified INTEGER DEFAULT 0,
    role TEXT DEFAULT 'user'
  );

  CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    ingredients TEXT,
    instructions TEXT,
    image_url TEXT,
    author_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(author_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    visitor_id TEXT
  );
`);

// Seed Initial Data
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
if (userCount.count === 0) {
  db.prepare("INSERT INTO users (email, password, name, role, verified) VALUES (?, ?, ?, ?, ?)").run('admin@foodhub.com', 'admin123', 'Admin Chef', 'admin', 1);
  db.prepare("INSERT INTO users (email, password, name, role, verified) VALUES (?, ?, ?, ?, ?)").run('user@foodhub.com', 'user123', 'Home Cook', 'user', 1);
  
  const recipes = [
    {
      title: "Grand Buffet Feast",
      description: "A massive spread of international delicacies, perfect for large gatherings. Includes everything from seafood to artisanal breads.",
      ingredients: "- Assorted seafood\n- Roast beef\n- Seasonal salads\n- International cheeses\n- Dessert selection",
      instructions: "1. Arrange food in heated trays.\n2. Organize by cuisine type.\n3. Ensure constant replenishment.\n4. Provide clear labels for allergens.",
      image_url: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200",
      author_id: 1
    },
    {
      title: "Classic Italian Margherita Pizza",
      description: "A timeless classic featuring fresh basil, creamy mozzarella, and a robust tomato sauce on a thin, crispy crust.",
      ingredients: "- 1 ball of pizza dough\n- 1/2 cup tomato sauce\n- 8oz fresh mozzarella\n- Fresh basil leaves\n- Olive oil",
      instructions: "1. Preheat oven to 500°F.\n2. Roll out dough.\n3. Spread sauce and add mozzarella.\n4. Bake for 10-12 minutes.\n5. Top with fresh basil.",
      image_url: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=1200",
      author_id: 1
    },
    {
      title: "Spicy Thai Green Curry",
      description: "An aromatic and flavorful curry made with fresh green chilies, coconut milk, and tender chicken or tofu.",
      ingredients: "- 2 tbsp green curry paste\n- 1 can coconut milk\n- 1lb chicken breast\n- Bamboo shoots\n- Thai basil",
      instructions: "1. Sauté curry paste in oil.\n2. Add coconut milk and simmer.\n3. Add chicken and vegetables.\n4. Cook until tender.\n5. Serve with jasmine rice.",
      image_url: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?auto=format&fit=crop&w=1200",
      author_id: 2
    },
    {
      title: "Decadent Chocolate Lava Cake",
      description: "A rich, gooey chocolate dessert that's surprisingly easy to make and perfect for special occasions.",
      ingredients: "- 4 oz dark chocolate\n- 1/2 cup butter\n- 2 eggs\n- 1/4 cup sugar\n- 2 tbsp flour",
      instructions: "1. Melt chocolate and butter.\n2. Whisk eggs and sugar.\n3. Combine and fold in flour.\n4. Pour into ramekins.\n5. Bake at 425°F for 12 minutes.",
      image_url: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=1200",
      author_id: 1
    }
  ];

  const insertRecipe = db.prepare("INSERT INTO recipes (title, description, ingredients, instructions, image_url, author_id) VALUES (?, ?, ?, ?, ?, ?)");
  recipes.forEach(r => insertRecipe.run(r.title, r.description, r.ingredients, r.instructions, r.image_url, r.author_id));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Analytics Middleware
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      return next();
    }
    const visitorId = req.headers['user-agent'] || 'unknown';
    db.prepare("INSERT INTO analytics (path, visitor_id) VALUES (?, ?)").run(req.path, visitorId);
    next();
  });

  // Auth Routes
  app.post("/api/auth/register", (req, res) => {
    const { email, password, name } = req.body;
    try {
      const info = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)").run(email, password, name);
      res.json({ success: true, userId: info.lastInsertRowid, message: "Registration successful. Please verify your email (simulated)." });
    } catch (e: any) {
      res.status(400).json({ success: false, error: e.message });
    }
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ? AND password = ?").get(email, password) as any;
    if (user) {
      res.json({ success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role, verified: user.verified } });
    } else {
      res.status(401).json({ success: false, error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/verify", (req, res) => {
    const { email } = req.body;
    db.prepare("UPDATE users SET verified = 1 WHERE email = ?").run(email);
    res.json({ success: true });
  });

  // Recipe Routes
  app.get("/api/recipes", (req, res) => {
    const recipes = db.prepare(`
      SELECT r.*, u.name as author_name 
      FROM recipes r 
      JOIN users u ON r.author_id = u.id 
      ORDER BY created_at DESC
    `).all();
    res.json(recipes);
  });

  app.get("/api/recipes/:id", (req, res) => {
    const recipe = db.prepare(`
      SELECT r.*, u.name as author_name 
      FROM recipes r 
      JOIN users u ON r.author_id = u.id 
      WHERE r.id = ?
    `).get(req.params.id);
    res.json(recipe);
  });

  app.post("/api/recipes", (req, res) => {
    const { title, description, ingredients, instructions, image_url, author_id } = req.body;
    const info = db.prepare(`
      INSERT INTO recipes (title, description, ingredients, instructions, image_url, author_id) 
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(title, description, ingredients, instructions, image_url, author_id);
    res.json({ success: true, recipeId: info.lastInsertRowid });
  });

  // Admin/Analytics Routes
  app.get("/api/admin/stats", (req, res) => {
    const totalUsers = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
    const totalRecipes = db.prepare("SELECT COUNT(*) as count FROM recipes").get() as any;
    const pageViews = db.prepare("SELECT COUNT(*) as count FROM analytics").get() as any;
    
    const viewsByDay = db.prepare(`
      SELECT date(timestamp) as date, COUNT(*) as count 
      FROM analytics 
      GROUP BY date(timestamp) 
      ORDER BY date DESC 
      LIMIT 7
    `).all();

    res.json({
      totalUsers: totalUsers.count,
      totalRecipes: totalRecipes.count,
      pageViews: pageViews.count,
      viewsByDay
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
