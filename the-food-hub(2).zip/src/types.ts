export interface User {
  id: number;
  email: string;
  name: string;
  role: 'user' | 'admin';
  verified: boolean;
}

export interface Recipe {
  id: number;
  title: string;
  description: string;
  ingredients: string;
  instructions: string;
  image_url: string;
  author_id: number;
  author_name: string;
  created_at: string;
}

export interface AnalyticsStats {
  totalUsers: number;
  totalRecipes: number;
  pageViews: number;
  viewsByDay: { date: string; count: number }[];
}
