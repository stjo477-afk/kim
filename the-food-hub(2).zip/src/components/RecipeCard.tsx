import { Link } from 'react-router-dom';
import { Recipe } from '../types';
import { Clock, Star, Heart } from 'lucide-react';
import { motion } from 'motion/react';

interface RecipeCardProps {
  recipe: Recipe;
}

export default function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
    >
      <Link to={`/recipe/${recipe.id}`}>
        <div className="relative h-64 overflow-hidden">
          <img 
            src={recipe.image_url || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600`} 
            alt={recipe.title} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full shadow-md hover:bg-[#F27D26] hover:text-white transition-colors">
            <Heart className="w-5 h-5" />
          </div>
          <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>25 MINS</span>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex items-center gap-1 text-yellow-500 mb-2">
            {[1, 2, 3, 4, 5].map(i => (
              <Star key={i} className="w-3 h-3 fill-current" />
            ))}
            <span className="text-gray-400 text-xs ml-1">(12)</span>
          </div>
          <h3 className="text-xl font-bold mb-2 group-hover:text-[#F27D26] transition-colors line-clamp-1">{recipe.title}</h3>
          <p className="text-gray-500 text-sm line-clamp-2 mb-4">{recipe.description}</p>
          
          <div className="flex items-center justify-between pt-4 border-t border-gray-50">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">By {recipe.author_name}</span>
            <span className="text-[#F27D26] font-bold text-sm">View Details</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
