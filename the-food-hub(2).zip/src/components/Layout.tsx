import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User } from '../types';
import { Search, User as UserIcon, LogOut, PlusCircle, LayoutDashboard } from 'lucide-react';
import AdBanner from './AdBanner';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
}

export default function Layout({ children, user, onLogout }: LayoutProps) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-[#1A1A1A] font-sans">
      {/* Top Ad */}
      <div className="bg-white border-b border-gray-200 py-2">
        <div className="max-w-7xl mx-auto px-4">
          <AdBanner type="leaderboard" />
        </div>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#F27D26] rounded-full flex items-center justify-center text-white font-bold text-xl">F</div>
            <span className="text-2xl font-bold tracking-tight text-[#1A1A1A]">THE FOOD HUB</span>
          </Link>

          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <input 
                type="text" 
                placeholder="Find a recipe..." 
                className="w-full bg-gray-100 border-none rounded-full py-2 pl-10 pr-4 focus:ring-2 focus:ring-[#F27D26] transition-all"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <nav className="flex items-center gap-6">
            <Link to="/" className="font-medium hover:text-[#F27D26] transition-colors">Recipes</Link>
            {user ? (
              <>
                <Link to="/create" className="flex items-center gap-1 font-medium hover:text-[#F27D26] transition-colors">
                  <PlusCircle className="w-5 h-5" />
                  <span>Post</span>
                </Link>
                {user.role === 'admin' && (
                  <Link to="/admin" className="flex items-center gap-1 font-medium hover:text-[#F27D26] transition-colors">
                    <LayoutDashboard className="w-5 h-5" />
                    <span>Admin</span>
                  </Link>
                )}
                <div className="flex items-center gap-3 pl-4 border-l border-gray-200">
                  <span className="text-sm font-semibold text-gray-600">Hi, {user.name}</span>
                  <button onClick={onLogout} className="text-gray-400 hover:text-red-500 transition-colors">
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-4">
                <Link to="/login" className="font-medium hover:text-[#F27D26] transition-colors">Login</Link>
                <Link to="/register" className="bg-[#F27D26] text-white px-5 py-2 rounded-full font-bold hover:bg-[#D66A1D] transition-colors">Sign Up</Link>
              </div>
            )}
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
        <div className="flex-1">
          {children}
        </div>
        
        {/* Sidebar Ads */}
        <aside className="hidden lg:block w-80 space-y-8">
          <div className="sticky top-24 space-y-8">
            <AdBanner type="rectangle" label="Sponsored Content" />
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
              <h3 className="font-bold text-lg mb-4">Trending Now</h3>
              <ul className="space-y-4">
                {[1, 2, 3, 4].map(i => (
                  <li key={i} className="flex gap-3 group cursor-pointer">
                    <div className="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={`https://images.unsplash.com/photo-1493770348161-369560ae357d?auto=format&fit=crop&w=100`} alt="Trending" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm leading-tight group-hover:text-[#F27D26] transition-colors">Best Ever 10-Minute Pasta Sauce</h4>
                      <p className="text-xs text-gray-500 mt-1">4.8 ★ (2.1k reviews)</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <AdBanner type="skyscraper" />
          </div>
        </aside>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-20 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-[#F27D26] rounded-full flex items-center justify-center text-white font-bold text-lg">F</div>
                <span className="text-xl font-bold tracking-tight">THE FOOD HUB</span>
              </div>
              <p className="text-gray-500 max-w-sm mb-6">
                The world's best kitchen companion. Join millions of home cooks and share your favorite recipes with the community.
              </p>
              <div className="flex gap-4">
                {['Facebook', 'Instagram', 'Pinterest', 'Twitter'].map(social => (
                  <a key={social} href="#" className="text-gray-400 hover:text-[#F27D26] transition-colors text-sm font-medium">{social}</a>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-4">Explore</h4>
              <ul className="space-y-2 text-gray-500 text-sm">
                <li><Link to="/">Latest Recipes</Link></li>
                <li><Link to="/">Popular Collections</Link></li>
                <li><Link to="/">Seasonal Favorites</Link></li>
                <li><Link to="/">Healthy Options</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-500 text-sm">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Editorial Policy</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-100 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-gray-400">© 2026 The Food Hub. All rights reserved.</p>
            <div className="flex gap-6">
              <AdBanner type="button" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
