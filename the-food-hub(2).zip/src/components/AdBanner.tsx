import React from 'react';

interface AdBannerProps {
  type: 'leaderboard' | 'rectangle' | 'skyscraper' | 'button';
  label?: string;
}

export default function AdBanner({ type, label = "Advertisement" }: AdBannerProps) {
  const styles = {
    leaderboard: "w-full h-24 md:h-32",
    rectangle: "w-full aspect-[4/3]",
    skyscraper: "w-full h-[600px]",
    button: "w-32 h-10"
  };

  return (
    <div className={`relative bg-gray-50 border border-gray-200 rounded-lg overflow-hidden flex flex-col items-center justify-center group ${styles[type]}`}>
      <div className="absolute top-1 left-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest z-10">
        {label}
      </div>
      
      {/* Simulated Ad Content */}
      <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center">
        <div className="w-12 h-12 bg-gray-200 rounded-full mb-2 flex items-center justify-center">
          <div className="w-6 h-6 bg-gray-300 rounded-sm"></div>
        </div>
        <div className="h-2 w-24 bg-gray-200 rounded-full mb-1"></div>
        <div className="h-2 w-16 bg-gray-100 rounded-full"></div>
      </div>

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-[#F27D26]/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <span className="text-[10px] font-bold text-[#F27D26] border border-[#F27D26] px-2 py-1 rounded uppercase">AdSense</span>
      </div>
    </div>
  );
}
