import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Recipe } from '../types';
import RecipeCard from '../components/RecipeCard';
import AdBanner from '../components/AdBanner';
import { ChevronRight, Flame, Clock, Users } from 'lucide-react';

export default function Home() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/recipes')
      .then(res => res.json())
      .then(data => {
        setRecipes(data);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#F27D26]"></div>
      </div>
    );
  }

  const featured = recipes[0];
  const others = recipes.slice(1);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      {featured && (
        <section className="relative group overflow-hidden rounded-3xl bg-white shadow-xl border border-gray-100">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-1/2 h-[400px] lg:h-[500px] overflow-hidden">
              <img 
                src={featured.image_url || `https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800`} 
                alt={featured.title} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
            </div>
            <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
              <div className="flex items-center gap-2 text-[#F27D26] font-bold text-sm uppercase tracking-widest mb-4">
                <Flame className="w-4 h-4" />
                <span>Featured Recipe</span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">{featured.title}</h1>
              <p className="text-gray-600 text-lg mb-8 line-clamp-3">{featured.description}</p>
              
              <div className="flex items-center gap-6 mb-8 text-sm text-gray-500 font-medium">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>45 Mins</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>4 Servings</span>
                </div>
                <div className="text-[#F27D26]">By {featured.author_name}</div>
              </div>

              <Link 
                to={`/recipe/${featured.id}`}
                className="inline-flex items-center gap-2 bg-[#1A1A1A] text-white px-8 py-4 rounded-full font-bold hover:bg-[#F27D26] transition-all w-fit"
              >
                <span>View Recipe</span>
                <ChevronRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Mid-page Ad */}
      <AdBanner type="leaderboard" label="Sponsored" />

      {/* Recipe Grid */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold">Latest Discoveries</h2>
          <Link to="/" className="text-[#F27D26] font-bold flex items-center gap-1 hover:underline">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {others.map((recipe, idx) => (
            <React.Fragment key={recipe.id}>
              <RecipeCard recipe={recipe} />
              {/* Inject ad every 4 items */}
              {(idx + 1) % 4 === 0 && (
                <div className="md:col-span-2">
                  <AdBanner type="leaderboard" />
                </div>
              )}
            </React.Fragment>
          ))}
          {others.length === 0 && !featured && (
            <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-gray-300">
              <p className="text-gray-400 font-medium">No recipes found. Be the first to post one!</p>
              <Link to="/create" className="text-[#F27D26] font-bold mt-2 inline-block">Post a Recipe</Link>
            </div>
          )}
        </div>
      </section>

      {/* Bottom Ad */}
      <AdBanner type="leaderboard" />
    </div>
  );
}
