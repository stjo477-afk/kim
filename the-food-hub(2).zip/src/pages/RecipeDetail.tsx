import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Recipe } from '../types';
import AdBanner from '../components/AdBanner';
import { Clock, Users, Printer, Share2, Bookmark, Star, ChevronLeft } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function RecipeDetail() {
  const { id } = useParams();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/recipes/${id}`)
      .then(res => res.json())
      .then(data => {
        setRecipe(data);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <div className="animate-pulse h-96 bg-gray-100 rounded-3xl" />;
  if (!recipe) return <div className="text-center py-20">Recipe not found.</div>;

  return (
    <div className="space-y-8">
      <Link to="/" className="inline-flex items-center gap-2 text-gray-500 hover:text-[#F27D26] font-medium transition-colors">
        <ChevronLeft className="w-5 h-5" />
        <span>Back to Recipes</span>
      </Link>

      <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100">
        <div className="relative h-[400px] md:h-[500px]">
          <img 
            src={recipe.image_url || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200`} 
            alt={recipe.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-8 left-8 right-8 text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{recipe.title}</h1>
            <div className="flex flex-wrap items-center gap-6 text-sm font-medium">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F27D26] flex items-center justify-center text-white font-bold">
                  {recipe.author_name[0]}
                </div>
                <span>By {recipe.author_name}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>45 MINS</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                <span>4 SERVINGS</span>
              </div>
              <div className="flex items-center gap-1 text-yellow-400">
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4" />
                <span className="text-white ml-1">(4.2)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-8 md:p-12">
          <div className="flex flex-col md:flex-row gap-12">
            <div className="flex-1 space-y-12">
              <section>
                <p className="text-xl text-gray-600 leading-relaxed italic">
                  "{recipe.description}"
                </p>
              </section>

              <AdBanner type="leaderboard" />

              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <span className="w-2 h-8 bg-[#F27D26] rounded-full" />
                  Ingredients
                </h2>
                <div className="bg-[#F9F8F6] p-8 rounded-2xl">
                  <div className="prose prose-orange max-w-none">
                    <ReactMarkdown>{recipe.ingredients}</ReactMarkdown>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                  <span className="w-2 h-8 bg-[#F27D26] rounded-full" />
                  Instructions
                </h2>
                <div className="prose prose-orange max-w-none">
                  <ReactMarkdown>{recipe.instructions}</ReactMarkdown>
                </div>
              </section>
            </div>

            <div className="md:w-80 space-y-8">
              <div className="flex gap-4">
                <button className="flex-1 flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 py-3 rounded-xl font-bold transition-colors">
                  <Printer className="w-5 h-5" />
                  <span>Print</span>
                </button>
                <button className="w-14 h-14 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors">
                  <Share2 className="w-5 h-5" />
                </button>
                <button className="w-14 h-14 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors">
                  <Bookmark className="w-5 h-5" />
                </button>
              </div>

              <AdBanner type="rectangle" />

              <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <h3 className="font-bold mb-4">Nutrition Facts</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between py-2 border-b border-gray-50">
                    <span className="text-gray-500">Calories</span>
                    <span className="font-bold">420 kcal</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-50">
                    <span className="text-gray-500">Total Fat</span>
                    <span className="font-bold">18g</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-50">
                    <span className="text-gray-500">Protein</span>
                    <span className="font-bold">12g</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-50">
                    <span className="text-gray-500">Carbs</span>
                    <span className="font-bold">54g</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AdBanner type="leaderboard" />
    </div>
  );
}
