import React, { useEffect, useState } from 'react';
import { User, AnalyticsStats } from '../types';
import { Users, BookOpen, Eye, TrendingUp, Calendar, ArrowUpRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface AdminDashboardProps {
  user: User | null;
}

export default function AdminDashboard({ user }: AdminDashboardProps) {
  const [stats, setStats] = useState<AnalyticsStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.role === 'admin') {
      fetch('/api/admin/stats')
        .then(res => res.json())
        .then(data => {
          setStats(data);
          setLoading(false);
        });
    }
  }, [user]);

  if (!user || user.role !== 'admin') {
    return <div className="text-center py-20">Access Denied.</div>;
  }

  if (loading || !stats) return <div className="animate-pulse h-96 bg-gray-100 rounded-3xl" />;

  const cards = [
    { title: 'Total Users', value: stats.totalUsers, icon: Users, color: 'bg-blue-500', trend: '+12%' },
    { title: 'Total Recipes', value: stats.totalRecipes, icon: BookOpen, color: 'bg-green-500', trend: '+5%' },
    { title: 'Page Views', value: stats.pageViews, icon: Eye, color: 'bg-purple-500', trend: '+24%' },
    { title: 'Conversion', value: '3.2%', icon: TrendingUp, color: 'bg-[#F27D26]', trend: '+1.5%' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Administrative Dashboard</h1>
          <p className="text-gray-500">Welcome back, {user.name}. Here's what's happening today.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-white border border-gray-200 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-gray-50 transition-colors">
            <Calendar className="w-4 h-4" />
            Last 7 Days
          </button>
          <button className="bg-[#1A1A1A] text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-[#F27D26] transition-colors">
            Export Data
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={`${card.color} p-3 rounded-xl text-white`}>
                <card.icon className="w-6 h-6" />
              </div>
              <div className="flex items-center gap-1 text-green-500 text-xs font-bold">
                <ArrowUpRight className="w-4 h-4" />
                {card.trend}
              </div>
            </div>
            <div className="text-gray-500 text-sm font-medium">{card.title}</div>
            <div className="text-3xl font-bold mt-1">{card.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-xl font-bold mb-8">Traffic Overview</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.viewsByDay.reverse()}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F27D26" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#F27D26" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F1F1" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#999'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#999'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="count" stroke="#F27D26" strokeWidth={3} fillOpacity={1} fill="url(#colorViews)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-xl font-bold mb-8">Recent Activity</h3>
          <div className="space-y-6">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold">
                  {['U', 'R', 'A', 'C', 'V'][i-1]}
                </div>
                <div>
                  <div className="text-sm font-bold">New recipe published</div>
                  <div className="text-xs text-gray-400">2 minutes ago</div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 text-[#F27D26] font-bold text-sm border border-[#F27D26] rounded-xl hover:bg-[#F27D26] hover:text-white transition-all">
            View All Activity
          </button>
        </div>
      </div>
    </div>
  );
}
