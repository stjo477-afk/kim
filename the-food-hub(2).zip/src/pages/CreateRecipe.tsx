import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User } from '../types';
import { Camera, Loader2, CheckCircle2 } from 'lucide-react';
import AdBanner from '../components/AdBanner';

interface CreateRecipeProps {
  user: User | null;
}

export default function CreateRecipe({ user }: CreateRecipeProps) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [image, setImage] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 shadow-sm">
        <h2 className="text-2xl font-bold mb-4">You need to be logged in to post a recipe.</h2>
        <button 
          onClick={() => navigate('/login')}
          className="bg-[#F27D26] text-white px-8 py-3 rounded-full font-bold hover:bg-[#D66A1D] transition-colors"
        >
          Login Now
        </button>
      </div>
    );
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data = {
      title: formData.get('title'),
      description: formData.get('description'),
      ingredients: formData.get('ingredients'),
      instructions: formData.get('instructions'),
      image_url: image,
      author_id: user.id
    };

    try {
      const res = await fetch('/api/recipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        setSuccess(true);
        setTimeout(() => navigate('/'), 2000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-gray-100 shadow-sm">
        <CheckCircle2 className="w-20 h-20 text-green-500 mb-6" />
        <h2 className="text-3xl font-bold mb-2">Recipe Posted!</h2>
        <p className="text-gray-500">Redirecting you to the home page...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100">
        <h1 className="text-3xl font-bold mb-8">Share Your Culinary Masterpiece</h1>
        
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-4">
            <label className="block font-bold text-gray-700">Recipe Image</label>
            <div 
              className="relative w-full h-64 bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-[#F27D26] transition-colors overflow-hidden"
              onClick={() => document.getElementById('image-input')?.click()}
            >
              {image ? (
                <img src={image} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <>
                  <Camera className="w-12 h-12 text-gray-300 mb-2" />
                  <span className="text-gray-400 font-medium">Click to upload a photo</span>
                </>
              )}
              <input 
                id="image-input"
                type="file" 
                accept="image/*" 
                onChange={handleImageChange}
                className="hidden" 
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block font-bold text-gray-700 mb-2">Recipe Title</label>
              <input 
                name="title"
                required
                placeholder="e.g. Grandma's Famous Lasagna"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-[#F27D26] outline-none transition-all"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-2">Short Description</label>
              <textarea 
                name="description"
                required
                rows={3}
                placeholder="Tell us a bit about this dish..."
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-[#F27D26] outline-none transition-all"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-2">Ingredients (Markdown supported)</label>
              <textarea 
                name="ingredients"
                required
                rows={6}
                placeholder="- 2 cups flour\n- 1 tsp salt..."
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl font-mono text-sm focus:ring-2 focus:ring-[#F27D26] outline-none transition-all"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 mb-2">Instructions (Markdown supported)</label>
              <textarea 
                name="instructions"
                required
                rows={8}
                placeholder="1. Preheat oven to 350°F...\n2. Mix dry ingredients..."
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl font-mono text-sm focus:ring-2 focus:ring-[#F27D26] outline-none transition-all"
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-[#F27D26] text-white py-4 rounded-xl font-bold text-lg hover:bg-[#D66A1D] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Publish Recipe'}
          </button>
        </form>
      </div>

      <AdBanner type="leaderboard" />
    </div>
  );
}
